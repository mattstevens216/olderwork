public abstract class Shape{
	public abstract Point position();
	public abstract double area();
}