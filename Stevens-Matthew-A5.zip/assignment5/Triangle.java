class Triangle extends Shape {
private final double a, b, c;
private Point location;

public Triangle(Point location, double a, double b, double c){
	this.location = location;
	this.a = a;
	this.b = b;
	this.c = c; //sides = sides
}

@Override
public double area(){
    double rea = (a + b + c) / 2; //perimeter div 2
	return Math.sqrt(rea * (rea - a) * (rea - b) * (rea - c)); //heron's area formula using addition of sides (perimeter)
}
@Override
		public Point position(){
		return location;
}
}