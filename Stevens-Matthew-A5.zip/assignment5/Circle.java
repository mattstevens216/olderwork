class Circle extends Shape{
	private double radius;
	private final double pi = Math.PI;
	private Point location;
	
	public Circle(Point location, double radius){
    this.radius = radius;
	this.location = location;
	}
	
	@Override
		public double area(){
		double radius2 = pi * radius * radius;
		return radius2;
	}
	@Override
		public Point position(){
		return location;
	}

}   
