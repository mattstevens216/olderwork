public class Position{
     public void positon(double x, double y){return point( x , y );}
}