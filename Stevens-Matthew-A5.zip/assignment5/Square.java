class Square extends Shape {
	private double width;
	private Point location;

	public Square(Point location, double width){
	this.width = width;
	this.location = location;
	}
	
	@Override
	public double area(){
	return width * width;
	}
	@Override
		public Point position(){
		return location;
	}
}