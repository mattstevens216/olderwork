class Rectangle extends Shape{
	public Point width;
	public Point length;

	public Rectangle(Point width, Point length){
		this.width = width;
		this.length = length;
	}
	
	@Override
	public double area(){
		double width1 = Math.abs(width.x - length.y);
		double length1 = Math.abs(length.x - width.y);
		return width1 * length1;
	}
	@Override
	public Point position(){
		return width;
	}
} //include readme file