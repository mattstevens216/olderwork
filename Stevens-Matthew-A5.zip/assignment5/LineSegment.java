class LineSegment extends Shape{
	public Point length;
	public Point location;

	public LineSegment(Point location, Point length){
	this.location = location;
	this.length = length;
	}
	
	@Override
	public double area(){
	return 0;
	}
	@Override
		public Point position(){
		return location;
	}
}