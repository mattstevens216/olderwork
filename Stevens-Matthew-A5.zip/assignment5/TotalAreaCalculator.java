class TotalAreaCalculator{
/*	public static void calculate(Shape[] shapes){
	for(int i = 0; i < Shapes.length(); i++){
			double area1 = Shapes(i).area + Shapes(i+1).area;
			}
	return area1;
	}
*/
}