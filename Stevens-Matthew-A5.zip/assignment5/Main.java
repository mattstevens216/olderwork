import java.util.*;
import java.awt.List;

class Main{
	
	public Shape[] randomShapes( Shape arraySize ){
	int m = 0;
	for(int i = 0; i < Shape.arraySize; ++i)
	m = Math.random() * 4;
	switch(m){
		case "0":
				System.out.println("Triangle");
				Point trianglePos = new Point(Math.random() * 800, Math.random() * 800);
				double a = Math.random()*100;	
				double b = Math.random()*100;
				double c = Math.random()*100;
				shape[i] = new Triangle(trianglePos, a, b, c);
		case "1":
				System.out.println("Rectangle");
				Point rectanglePos = new Point(Math.random() * 800, Math.random() * 800);
				double width = Math.random()*100;
				double length = Math.random()*100;
				shape[i] = new Rectangle(rectanglePos, width, length);
		case "2":
				System.out.println("Circle");
				Point circlePos = new Point(Math.random() * 800, Math.random() * 800);
				double radius = Math.random()*100;
				shape[i] = new Rectangle(rectanglePos, radius);
		case "3":
				System.out.println("LineSegment");
				Point linePos = new Point(Math.random() * 800, Math.random() * 800);
				double length = Math.random()*100;
				shape[i] = new Rectangle(rectanglePos, width, length);
		case "4":
				System.out.println("Square");
				Point squarePos = new Point(Math.random() * 800, Math.random() * 800);
				double width = Math.random()*100;
				shape[i] = new Square(squarePos, width);
	}
	return shape[i];
	
	
	
	}//do last
 //first finish reads in main, then do randomShapes then do equals


	public static Shape[] input(String s){
		Scanner parse = new Scanner(s);
		String schar = parse.findInLine(";");
		while(schar != null){
			arraySize++;
			schar = parse.findInLine(";");
		}
		Shape[] shapes = new Shape(arraySize);
		System.out.println(arraySize + " shapes");
		
		parse = new Scanner(s);
		parse.useDelimiter(";");
		int i = 0;
		
		while(parse.hasNext()){
			String shape = parse.next();
			Scanner scan = new Scanner(shape);
			String type = scan.next();
			switch(type){
				case "t":
						System.out.println("Triangle" + ++t_cnt);
						break;
				case "r":
						System.out.println("Rectangle" + ++r_cnt);
						break;
				case "s":
						System.out.println("Square" + ++s_cnt);
						break;
				case "c":
						System.out.println("Circle" + ++c_cnt);

						break;
				case "l":
						System.out.println("LineSegment" + ++l_cnt);
			}
		}
		System.out.println(i + " shapes");
		return shapes;
		}
		
		public static Shape[] shapes;
		public static int arraySize = 0, t_cnt = 0,
					  r_cnt = 0, s_cnt = 0, c_cnt = 0, l_cnt = 0;
	
		public static void main(String args[]){
			double area = 0; //initialize
			Shape shape[] = new Shape[args.length];
			if (args[0].equals("S"))
				for(int i = 0; i<shape.length; ++i){
				String [] result = args[i].split(" "); //input vector will be of different size than result string
				
					for (int k = 0; k< result.length; ++k){//System.out.println(result[k]);
						if (result[k].equals("c") && ( (result.length-1) == 3) ){ //initialize circle with points
							Point circlePos = new Point(result[1], result[2]);//using Double.parseDouble to convert string into a double
							double radius = Double.parseDouble(result[3]); // radius is last element of string
							shape[i] = new Circle(circlePos, radius);//put circle shape into the shape array
						}
						else if (result[k].equals("t") && ( (result.length-1) == 5) ){ //initialize circle with points
							Point trianglePos = new Point(result[1], result[2]);//using Double.parseDouble to convert string into a double
							double a = Double.parseDouble(result[3]);					// radius is last element of string
							double b = Double.parseDouble(result[4]);
							double c = Double.parseDouble(result[5]);
							shape[i] = new Triangle(trianglePos, a, b, c);//put circle shape into the shape array
						}
						else if (result[k].equals("r") && ( (result.length-1) == 4) ){ //initialize circle with points
							Point rectanglePos = new Point(result[1], result[2]);//using Double.parseDouble to convert string into a double
							double width = Double.parseDouble(result[3]); // radius is last element of string
							double length = Double.parseDouble(result[4]);
							shape[i] = new Rectangle(rectanglePos, width, length);//put circle shape into the shape array
						}
						else if (result[k].equals("s") && ( (result.length-1) == 3) ){ //initialize circle with points
							Point squarePos = new Point(result[1], result[2]);//using Double.parseDouble to convert string into a double
							double width = Double.parseDouble(result[3]); // radius is last element of string
							shape[i] = new Square(squarePos, width);//put circle shape into the shape array
						}
						else if (result[k].equals("l") && ( (result.length-1) == 3) ){ //initialize circle with points
							Point linePos = new Point(result[1], result[2]);//using Double.parseDouble to convert string into a double
							double length = Double.parseDouble(result[3]); // radius is last element of string
							shape[i] = new LineSegment(linePos, length);//put circle shape into the shape array
						}
						else System.exit(0);
				}
			
		
			}
			else if (args[0].equals("R")){
				arraySize = integer.parseInt( args[1] ); //if R or S
				shapes = randomShapes( arraySize );
			}

			
		}
	 


	 
	 
	 
	 
}